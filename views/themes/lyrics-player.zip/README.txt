A Pen created at CodePen.io. You can find this one at https://codepen.io/z-/pen/MQRGOe.

 ![](https://i.imgur.com/ftrTV2J.gif)

I wanted to make a POC for a lyric viewer, so I did.

Input is manual, but it's basically capturing the timestamp in which the lyric should be shown - which if I were to turn this into a product I would be bothered to do.